from WEB.SQLAlchemy.Задачи.Captain.data import db_session
from WEB.SQLAlchemy.Задачи.Captain.data.userss import User
from WEB.SQLAlchemy.Задачи.Captain.data.jobs import Jobs
from flask import Flask, render_template

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route("/")
def index():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    return render_template("index.html", jobs=jobs)


def main():
    db_session.global_init("db/sail.db")

    app.run(port=8080, host='192.168.0.105')


if __name__ == '__main__':
    main()
